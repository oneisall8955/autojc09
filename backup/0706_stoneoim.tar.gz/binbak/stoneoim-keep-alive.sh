#! /bin/sh

# Author       : WangGuanran
# Email        : wangguanran@stoneoim.com
# Date         : 2022-07-06 22:22:02
# LastEditTime : 2022-09-15 15:49:47
# LastEditors  : WangGuanran
# Description  : stoneoim keep alive shell scripts
# FilePath     : /zprojects/common/meta-stoneoim/recipes-service/files/stoneoim-keep-alive.sh

LOGPATH="/dev/kmsg"

if [ $# != 1 ] ; then
    echo "USAGE: $0 app" >> $LOGPATH
    echo " e.g : $0 stoneoim-service" >> $LOGPATH
    exit 1
fi

APP=$1
echo "$0 : keep alive app name '$APP'" >> $LOGPATH

count=0
while true
do
    time=$(date "+%Y-%m-%d %H:%M:%S")
    pid=`pidof $APP`
    # echo "$0 : $APP's pid = $pid" >> $LOGPATH
    if [ ! -n "$pid" ]; then
        let count+=1
        echo "$0 : current timer = '$time'" >> $LOGPATH
        echo "$0 : the $APP is dead.restart... count=$count" >> $LOGPATH
        start-stop-daemon --start --background --exec $APP
    fi
    sleep 5
done